<!DOCTYPE html>
<html lang="en">
    <head>
        <title>BMkonto &copy; <?php echo date("Y"); ?></title>
        <meta name="description" content="BMkonto is a personal blog about Bongo's life. Here you will find various things ranging from projects, personal life and every fun thing under the sun">
        <meta name="viewport" content="width=device-width=initial-scale=1.0">
        <meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <link rel="stylesheet" type="text/css" href="css/css-grid.css">
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <script type="text/javascript" src="js/sidebar.js"></script>
    </head>
    <body>
        <div class="page-container col-wd-12 col-md-12 col-sm-12">
            <div class="content-container col-wd-12 col-md-12 col-sm-12">
                <div class="content col-wd-12 col-md-12 col-sm-12">
                    <!-- navigation -->
                    <div id="side-nav" class="side-nav col-wd-4 col-md-4 col-sm-4">
                        <nav>
                            <div class="close-nav">
                                <a href="javascript:void(0)" id="close-nav"><span>&times;</span></a>
                            </div>
                            <ul>
                                <li><a href="#">Home</a></li>
                                <li><a href="#">Portfolio</a></li>
                                <li><a href="#">Media</a></li>
                                <li><a href="#">About Me</a></li>
                            </ul>
                        </nav>
                    </div>
                    <!-- content -->
                    <div id="right-content" class="right-content col-wd-8 col-md-8 col-sm-8">
                        <p id="nav-button" class="nav-button col-wd-3 col-md-3 col-sm-3">
                            <span>&#9776;</span>
                        </p>
                        <h2 class="content-header col-wd-9 col-md-9 col-sm-9">Right Side Content</h2>
                        <div class="article col-wd-12 col-md-12 col-sm-12">
                            <p>This will be my homepage content</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
    <script type="text/javascript">
        new sidenav();
    </script>
</html>