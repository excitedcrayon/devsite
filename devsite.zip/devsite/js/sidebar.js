function sidenav(){
    window.onload = this.init();
}

sidenav.prototype.init = function(){
    alert('Test')
    this.openNav();
}

sidenav.prototype.openNav = function(){
    var nav = document.getElementById('side-nav');
    var content = document.getElementById('right-content');
    var bars = document.getElementById('nav-button');
    bars.addEventListener("click", function(){
        alert('clicked nav button');
        nav.style.width = "250px";
        content.style.marginLeft = "250px";
    });
}
