function sidenav(){
    window.onload = this.init();
}

sidenav.prototype.init = function(){
    //alert('Test')
    this.openNav();
    this.closeNav();
}

sidenav.prototype.openNav = function(){
    var nav = document.getElementById('side-nav');
    var content = document.getElementById('right-content');
    var bars = document.getElementById('nav-button');
    bars.addEventListener("click", function(){
        //alert('clicked nav button');
        nav.style.width = "250px";
        content.style.marginLeft = "250px";
    },false);
}

sidenav.prototype.closeNav = function(){
    var nav = document.getElementById("side-nav");
    var content = document.getElementById("right-content");
    var closeButton = document.getElementById("close-nav");
    closeButton.addEventListener("click", function(){
        nav.style.width= "0";
        content.style.marginLeft = "0";
    }, false);
}